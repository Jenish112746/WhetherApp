package com.example.whetherreport.presenter

import com.example.whetherreport.CurrentWeatherCallback
import com.example.whetherreport.DetailedWeatherCallback
import com.example.whetherreport.model.CurrentWeatherResponse
import com.example.whetherreport.model.FullDetailsResponse
import com.example.whetherreport.model.MainContract
import com.example.whetherreport.model.MainModel


class MainPresenter(view: MainContract.View) : MainContract.Presenter {

    private var view: MainContract.View = view
    private var model: MainContract.Model = MainModel()

    override fun startLoadingData(lat:Double, lon:Double) {

        // load WeatherData From Server
        model.loadCurrentWeatherData(lat, lon,object : CurrentWeatherCallback {
            override fun onLoadSuccess(currentWeatherResponse: CurrentWeatherResponse?) {
                // Pass data to view
                view.onCurrentDataLoadFinished(currentWeatherResponse)
            }

            override fun onLoadFailure(errorMessage: String?) {
                // Pass errorMessage to view
                view.onLoadFailed(errorMessage!!)
            }
        })


        // load Detailed Data From Server
        model.loadDetailedWeatherData(lat, lon, object : DetailedWeatherCallback {
            override fun onLoadSuccess(fullDetailsResponse: FullDetailsResponse?) {
                // Pass data to view
                view.onDetailedDataLoadFinished(fullDetailsResponse)
            }

            override fun onLoadFailure(errorMessage: String?) {
                // Pass errorMessage to view
                view.onLoadFailed(errorMessage!!)
            }
        })
    }
}