package com.example.whetherreport.model

import android.util.Log
import com.example.whetherreport.CurrentWeatherCallback
import com.example.whetherreport.DetailedWeatherCallback
import com.example.whetherreport.MainActivity
import com.example.whetherreport.data.RetrofitClient
import com.example.whetherreport.utils.Constant
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainModel : MainContract.Model {

    override fun loadCurrentWeatherData(lat :Double, lon :Double, callback: CurrentWeatherCallback) {

        RetrofitClient.getWeatherService().getWeatherData(lat, lon, MainActivity.unit!!, Constant.API_KEY)
            .enqueue(object : Callback<CurrentWeatherResponse> {
                override fun onFailure(call: Call<CurrentWeatherResponse>, t: Throwable) {
                    Log.e("LOADFAILED","---->"+t.message)
                    callback.onLoadFailure(t.message)
                }

                override fun onResponse(call: Call<CurrentWeatherResponse>, response: Response<CurrentWeatherResponse>) {
                    if (response.isSuccessful){
                        Log.e("LOADSUCCESFULLY", "---->$response")
                        callback.onLoadSuccess(response.body())
                    }
                }
            })
    }

    override fun loadDetailedWeatherData(lat :Double, lon :Double, callback: DetailedWeatherCallback) {
        RetrofitClient.getWeatherService().getDetailedWeatherData(lat ,lon , MainActivity.unit!!,Constant.EXCLUDE,Constant.API_KEY)
            .enqueue(object : Callback<FullDetailsResponse> {
                override fun onFailure(call: Call<FullDetailsResponse>, t: Throwable) {
                    callback.onLoadFailure(t.message)
                }

                override fun onResponse(call: Call<FullDetailsResponse>, response: Response<FullDetailsResponse>) {
                    if (response.isSuccessful){
                        callback.onLoadSuccess(response.body())
                    }
                }
            })
    }
}
