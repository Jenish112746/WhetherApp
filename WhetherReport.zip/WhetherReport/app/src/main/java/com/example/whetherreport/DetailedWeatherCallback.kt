package com.example.whetherreport

import com.example.whetherreport.model.FullDetailsResponse


interface DetailedWeatherCallback {
    fun onLoadSuccess(fullDetailsResponse: FullDetailsResponse?)
    fun onLoadFailure(errorMessage: String?)
}