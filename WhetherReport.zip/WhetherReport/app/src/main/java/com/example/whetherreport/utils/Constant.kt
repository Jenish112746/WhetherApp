package com.example.whetherreport.utils

import com.example.whetherreport.BuildConfig


class Constant {
    companion object {
        const val API_KEY = BuildConfig.API_KEY
        const val UNIT_NAME = "metric"
        const val CITY_NAME = "Rajkot,in"

        const val LAT = 31.22
        const val LON = 29.96

        const val Rajkot_LAT = 22.30
        const val Rajkot_LON = 70.80

        const val EXCLUDE = "current,minutely"

        const val CURRENT_WEATHER = "weather"
    }
}