package com.example.whetherreport

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Recycler
import com.example.whetherreport.adapetr.DailyWeatherAdapter
import com.example.whetherreport.adapetr.HourlyWeatherAdapter
import com.example.whetherreport.location.LocationCallback
import com.example.whetherreport.location.LocationService
import com.example.whetherreport.location.LocationStorage
import com.example.whetherreport.model.*
import com.example.whetherreport.presenter.MainPresenter
import com.example.whetherreport.utils.Constant
import com.example.whetherreport.utils.DataStorage.Companion.setDataStatus
import com.example.whetherreport.utils.Time
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices


class MainActivity : AppCompatActivity(), MainContract.View,LocationCallback,SharedPreferences.OnSharedPreferenceChangeListener {

    private var mFusedLocationClient: FusedLocationProviderClient? = null
    private var mLastLocation: Location? = null
    private var mLatitudeLabel: String? = null
    private var mLongitudeLabel: String? = null
    val CITY: String = "Rajkot"
//    lateinit var locButton: Button
    lateinit var cityName: String
//    lateinit var toogleLottie: LottieAnimationView
    val apiKey: String = "5f6f086fd30a86a94be1d1559f602782"
    var toogIdentifier: String = "night"
    private lateinit var presenter: MainPresenter
    private lateinit var txtTemperature: TextView
    private lateinit var txtHighTemperature: TextView
    private lateinit var txtLowTemperature: TextView
    private lateinit var txtWeatherDescription: TextView
    private lateinit var txtLocation: TextView
    private lateinit var txtLastUpdated: TextView
    private lateinit var currentWeatherLayout: LinearLayout
    var hourlyRecyclerView: RecyclerView? = null
    var lat: Double = 0.0
    var lon: Double = 0.0
//    private lateinit var viewOne: View
//    private lateinit var viewTwo: View
    private lateinit var locationService: LocationService
    private var locationManager: LocationManager? = null
    var dailyRecyclerView : RecyclerView? = null
    var today : TextView? = null
    var weekly : TextView? = null
    var switchOnOff : SwitchCompat? = null
    var whether_icon : ImageView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mLatitudeLabel = resources.getString(R.string.latitude_label)
        mLongitudeLabel = resources.getString(R.string.longitude_label)
        txtTemperature = findViewById(R.id.txtTemperaturee)
        dailyRecyclerView = findViewById(R.id.rcDailyWeatherList)
        currentWeatherLayout = findViewById(R.id.currentWeatherLayout_main)
        hourlyRecyclerView = findViewById<RecyclerView>(R.id.rcHourlyWeatherList)
//        toogleLottie = findViewById<LottieAnimationView>(R.id.hamster)
//        locButton = findViewById<Button>(R.id.round_button)
        txtHighTemperature = findViewById(R.id.txtHighTemperature)
        txtLowTemperature = findViewById(R.id.txtLowTemperature)
        txtWeatherDescription = findViewById(R.id.txtWeatherDescription)
        txtLocation = findViewById(R.id.txtLocation)
        txtLastUpdated = findViewById(R.id.txtLastUpdated)
        today = findViewById(R.id.tvToday)
        weekly = findViewById(R.id.tvWeekly)
        switchOnOff = findViewById(R.id.swOnOff)
//        viewOne = findViewById(R.id.viewOne)
//        viewTwo = findViewById(R.id.viewTwo)
        presenter = MainPresenter(this)
        locationService = LocationService(this, this)

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        switchOnOff!!.setSwitchTextAppearance(this, R.style.SwitchTextAppearance)




//        toogleLottie.setOnClickListener {
//            if (toogIdentifier == "night") {
//                toogleLottie.playAnimation()
//                findViewById<LottieAnimationView>(R.id.animation_view).setAnimation(R.raw.day_background)
//                toogIdentifier = "day"
//            } else {
//                findViewById<LottieAnimationView>(R.id.animation_view).setAnimation(R.raw.night_background)
//                toogIdentifier = "night"
//                toogleLottie.frame = 1
//            }
//            findViewById<LottieAnimationView>(R.id.animation_view).playAnimation()
//        }
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(
            this
        )
        unit = sharedPreferences.getString(
            getString(R.string.unit_key),
            getString(R.string.celsius_value)
        )

        loadWeatherData()

        switchOnOff!!.setOnCheckedChangeListener { _, isChecked ->

            if (isChecked) {
                dailyRecyclerView!!.visibility = View.VISIBLE
                weekly!!.visibility = View.VISIBLE
                hourlyRecyclerView!!.visibility = View.GONE
                today!!.visibility = View.GONE

            } else {
                dailyRecyclerView!!.visibility = View.GONE
                weekly!!.visibility = View.GONE
                hourlyRecyclerView!!.visibility = View.VISIBLE
                today!!.visibility = View.VISIBLE
            }
        }
    }
    @RequiresApi(Build.VERSION_CODES.M)
    public override fun onStart() {
        super.onStart()

        if (!checkPermissions()) {
            requestPermissions()
        } else {
            getLastLocation()
        }
    }

    @SuppressLint("MissingPermission")
    private fun getLastLocation() {
        mFusedLocationClient!!.lastLocation
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful && task.result != null) {
                    mLastLocation = task.result

                } else {
                    findViewById<TextView>(R.id.txtTemperaturee).text =
                        "Location Error.\nTry by using City name"
                }
            }
    }

    private fun showSnackbar(
        mainTextStringId: Int, actionStringId: Int,
        listener: View.OnClickListener,
    ) {

        Toast.makeText(this@MainActivity, getString(mainTextStringId), Toast.LENGTH_LONG).show()
    }

    private fun checkPermissions(): Boolean {
        val permissionState = ActivityCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_COARSE_LOCATION)
        return permissionState == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(this@MainActivity,
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE)
    }

    private fun requestPermissions() {
        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(this,
            Manifest.permission.ACCESS_COARSE_LOCATION)

        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")

            showSnackbar(R.string.permission_rationale, android.R.string.ok,
                View.OnClickListener {
                    // Request permission
                    startLocationPermissionRequest()
                })

        } else {
            Log.i(TAG, "Requesting permission")
            // Request permission. It's possible this can be auto answered if device policy
            // sets the permission in a given state or the user denied the permission
            // previously and checked "Never ask again".
            startLocationPermissionRequest()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            // If request is not cancelled, the result arrays are full.
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // permission was granted, yay! Do the location-related task you need to do.
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    )
                    == PackageManager.PERMISSION_GRANTED
                ) {

                    // Request location updates
                    locationManager?.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        10000L,
                        500f,
                        locationService
                    )

                    locationManager?.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        10000L,
                        500f,
                        locationService
                    )
                    locationManager?.requestLocationUpdates(
                        LocationManager.PASSIVE_PROVIDER,
                        10000L,
                        500f,
                        locationService
                    )
                }
            } else {
                // User refused
                presenter.startLoadingData(Constant.Rajkot_LAT, Constant.Rajkot_LON)
            }
        }
    }

    companion object {

        private const val TAG = "LocationProvider"

        var unit: String? = null
        private const val REQUEST_PERMISSIONS_REQUEST_CODE = 34
    }

    override fun onCurrentDataLoadFinished(currentWeatherResponse: CurrentWeatherResponse?) {
        if (currentWeatherResponse != null) {
            val temperature =
                getString(R.string.temperature, currentWeatherResponse.main.temp.toInt())
            txtTemperature.text = temperature


            txtWeatherDescription.text = currentWeatherResponse.weather[0].description
            txtLocation.text = currentWeatherResponse.name
            val lastUpdated =
                getString(R.string.lastUpdated, Time.timeConverter(currentWeatherResponse.dt))
            txtLastUpdated.text = lastUpdated

        }
    }

    override fun onDetailedDataLoadFinished(fullDetailsResponse: FullDetailsResponse?) {
        Log.e("Callingitttttttt", "")
        if (fullDetailsResponse != null) {
            if (fullDetailsResponse != null) {
                // Get Hourly weather
                val horizontalLayoutManager =
                    LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
                hourlyRecyclerView!!.layoutManager = horizontalLayoutManager
                hourlyRecyclerView!!.setHasFixedSize(true)

                val dividerItemDecoration = DividerItemDecoration(
                    hourlyRecyclerView!!.context,
                    horizontalLayoutManager.orientation
                )
                hourlyRecyclerView!!.addItemDecoration(dividerItemDecoration)

                val listOfHourlyWeather: List<Hourly> = fullDetailsResponse.hourly
                Log.e("hdvgdcccccccgd", "" + listOfHourlyWeather)
                val mHourlyWeatherAdapter = HourlyWeatherAdapter(listOfHourlyWeather, this)
                hourlyRecyclerView!!.adapter = mHourlyWeatherAdapter

                // Get Daily weather

                val verticalLayoutManager =
                    LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
                dailyRecyclerView!!.layoutManager = verticalLayoutManager
                dailyRecyclerView!!.setHasFixedSize(true)
                dailyRecyclerView!!.isNestedScrollingEnabled = false


                val verticalItemDecoration = DividerItemDecoration(dailyRecyclerView!!.context,
                    verticalLayoutManager.orientation)
                dailyRecyclerView!!.addItemDecoration(verticalItemDecoration)

                val listOfDailyWeather: List<Daily> = fullDetailsResponse.daily

                val mDailyWeatherAdapter = DailyWeatherAdapter(listOfDailyWeather, this)
                dailyRecyclerView!!.adapter = mDailyWeatherAdapter

                val highTemperature =
                    getString(R.string.high_temperature, listOfDailyWeather[0].temp.max.toInt())
                txtHighTemperature.text = highTemperature
                val lowTemperature =
                    getString(R.string.low_temperature, listOfDailyWeather[0].temp.min.toInt())
                txtLowTemperature.text = lowTemperature
            }
        }
    }

    override fun onLoadFailed(error: String) {
        Log.d(TAG, error)
    }

    private fun loadWeatherData() {
        if (com.example.whetherreport.utils.Network.isOnline(this)) {
            if (LocationStorage.getLoc(this).getLat() != null && LocationStorage.getLoc(this)
                    .getLon() != null
            ) {
                lat = LocationStorage.getLoc(this).getLat()!!.toDouble()
                lon = LocationStorage.getLoc(this).getLon()!!.toDouble()
                presenter.startLoadingData(lat, lon)
            } else {
                // User refused permission, Rajkot is added as a default
                presenter.startLoadingData(Constant.Rajkot_LAT, Constant.Rajkot_LON)
            }
        } else {

        }
    }

    override fun onLocationResult() {
        Log.d(TAG, "onLocationResult: It's First Time")
        lat = LocationStorage.getLoc(this).getLat()!!.toDouble()
        lon = LocationStorage.getLoc(this).getLon()!!.toDouble()
        presenter.startLoadingData(lat, lon)
        setDataStatus(this, true)
    }

    override fun onSharedPreferenceChanged(p0: SharedPreferences?, key: String?) {
        if (key.equals(getString(R.string.unit_key))) {
            unit = p0?.getString(
                getString(R.string.unit_key),
                getString(R.string.celsius_value)
            )
            if (LocationStorage.getLoc(this).getLat() != null && LocationStorage.getLoc(this)
                    .getLon() != null
            ) {
                presenter.startLoadingData(lat, lon)
            } else {
                presenter.startLoadingData(Constant.Rajkot_LAT, Constant.Rajkot_LON)
            }
        }


    }


}


