package com.example.whetherreport.location

interface LocationCallback {
    fun onLocationResult()
}