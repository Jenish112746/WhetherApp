package com.example.whetherreport

import com.example.whetherreport.model.CurrentWeatherResponse


interface CurrentWeatherCallback {
    fun onLoadSuccess(currentWeatherResponse: CurrentWeatherResponse?)
    fun onLoadFailure(errorMessage: String?)
}