package com.example.whetherreport.adapetr

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.whetherreport.R
import com.example.whetherreport.model.Hourly
import com.example.whetherreport.utils.Time
import com.squareup.picasso.Picasso




class HourlyWeatherAdapter(private val hourlyDataList: List<Hourly>, private val context: Context) : RecyclerView.Adapter<HourlyWeatherAdapter.HourlyWeatherHolder>() {

    var clicked : Int? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HourlyWeatherHolder {
        val inflater: LayoutInflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.hourly_list_item, parent, false)
        return HourlyWeatherHolder(view)
    }

    override fun onBindViewHolder(holder: HourlyWeatherHolder, position: Int) {
        val currentHourlyWeather: Hourly = hourlyDataList[position]



        holder.itemView.setOnClickListener {
            clicked = position
            Log.e("gdtcxfvcd ","-->"+clicked)
            notifyDataSetChanged()
            }
        if (clicked == position){
            Log.e("ggcvgcvc","======>")
            holder.layout.setBackgroundResource(R.drawable.gradient)
        }
        else {
            holder.layout.setBackgroundResource(R.color.black)
        }

        val hour: String = Time.timeConverter(currentHourlyWeather.dt)
        holder.txtHour.text = hour

        val iconCode = currentHourlyWeather.weather[0].icon
        Log.e("ICONCODEGET",""+iconCode)
        val imageUrl = "http://openweathermap.org/img/w/$iconCode.png"
        Picasso.get()
            .load(imageUrl)
            .into(holder.imgIcon, object : com.squareup.picasso.Callback {
                override fun onSuccess() {
                    Log.d("icon", "success")
                }

                override fun onError(e: Exception?) {
                    Log.d("icon", "error"+e!!.message)
                }
            })

        val temperature: String = context.getString(R.string.hourly_temperature, currentHourlyWeather.temp.toInt())
        holder.txtTemperature.text = temperature
    }

    override fun getItemCount(): Int {
        return hourlyDataList.size
    }

    class HourlyWeatherHolder(itemView : View) : RecyclerView.ViewHolder(itemView) {
        var txtHour: TextView = itemView.findViewById(R.id.txtHour)
        var imgIcon: ImageView = itemView.findViewById(R.id.imgIcon)
        var txtTemperature : TextView = itemView.findViewById(R.id.txtTemperature)
        var layout : LinearLayout = itemView.findViewById(R.id.hour_layout)

    }
}